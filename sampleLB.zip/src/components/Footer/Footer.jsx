import React from "react";

const Footer = () => {
    return (
        <div className="w-full px-8">
            {/* Glow */}
            <div
                class="absolute -top-10 left-1/2 -translate-x-1/2 
              w-[80%] h-40
              bg-[radial-gradient(circle,rgba(51,136,230,0.4)_0%,rgba(51,136,230,0)_70%)]
              blur-3xl
              -z-10"
            ></div>
            <footer className="w-full bg-[#111111] text-white rounded-t-3xl mt-10 p-10 border border-[#404c52]">
                <div className="max-w-6xl mx-auto flex flex-row justify-between">
                    {/* LOGO + COPYRIGHT */}
                    <div className="space-y-2">
                        {/* Placeholder Logo */}
                        <div className="w-32 h-10 rounded-md flex items-center justify-center">
                            <img src="/public/footer/logo.svg" alt="Footer Logo" />
                        </div>

                        <p className="text-sm text-gray-400 mt-6 font-semibold">© 2025 Voided.gg</p>
                        <p className="text-sm text-gray-400 font-semibold">All Rights Reserved</p>
                    </div>

                    <div className="flex flex-row justify-between gap-40">
                        {/* PAGES */}
                        <div>
                            <h3 className="text-white font-semibold mb-2 tracking-wide">PAGES</h3>
                            <ul className="space-y-2">
                                <li className="text-green-400 cursor-pointer hover:text-green-300 transition font-semibold">
                                    Leaderboard
                                </li>
                                <li className="text-gray-400 cursor-pointer hover:text-white font-semibold">Bonuses</li>
                                <li className="text-gray-400 cursor-pointer hover:text-white flex items-center gap-1 font-semibold">
                                    Stream <img src="/public/footer/link.svg" alt="link" />
                                </li>
                            </ul>
                        </div>

                        {/* SOCIALS */}
                        <div>
                            <h3 className="text-white font-semibold mb-2 tracking-wide">SOCIALS</h3>
                            <ul className="space-y-3">
                                <li className="flex items-center gap-2 text-gray-400 font-semibold">
                                    <img src="/public/footer/twitter.svg" alt="twitter" />
                                    Twitter
                                </li>

                                <li className="flex items-center gap-2 text-gray-400 font-semibold">
                                    <img src="/public/footer/discord.svg" alt="discord" />
                                    Discord
                                </li>

                                <li className="flex items-center gap-2 text-gray-400 font-semibold">
                                    <img src="/public/footer/twitter.svg" alt="twitter" />
                                    Twitter (Prizes)
                                </li>
                            </ul>
                        </div>

                        {/* PARTNERS */}
                        <div>
                            <h3 className="text-white font-semibold mb-2 tracking-wide">PARTNERS</h3>
                            <ul className="space-y-2">
                                <li className="flex items-center gap-1 text-gray-400 font-semibold">
                                    Stake.com <img src="/public/footer/link.svg" alt="link" />
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    );
};

export default Footer;
