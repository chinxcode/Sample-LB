import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Leaderboard } from "./components/leaderboard/Leaderboard";
import Footer from "./components/Footer/Footer";

function App() {
    return (
        <BrowserRouter>
            <div className="min-h-screen bg-[#111111]">
                <main className="min-h-screen">
                    <Routes>
                        <Route path="/" element={<Leaderboard />} />
                    </Routes>
                </main>
                <Footer />
            </div>
        </BrowserRouter>
    );
}

export default App;
